//
//  Model.swift
//  ShoppingAppMachineTest
//
//  Created by Mc on 22/03/24.
//

import Foundation

// MARK: - Welcome
struct Welcome: Codable {
    let status: String?
    let message: String?
    let data: DataClass?

    enum CodingKeys: String, CodingKey {
        case status, message, data
    }
}

// MARK: - DataClass
struct DataClass: Codable {
    let availableDates: AvailableDates?
    let product: [Product]?

    enum CodingKeys: String, CodingKey {
        case availableDates = "available_dates"
        case product
    }
}

// MARK: - AvailableDates
struct AvailableDates: Codable {
    let currentMonthScrapAvailability: String?
    let nextMonthScrapAvailability: String?

    enum CodingKeys: String, CodingKey {
        case currentMonthScrapAvailability = "current_month_scrap_availability"
        case nextMonthScrapAvailability = "next_month_scrap_availability"
    }
}

// MARK: - Product
struct Product: Codable, Identifiable, Equatable {
    let id, name, price, type: String?
    let image: String?

    enum CodingKeys: String, CodingKey {
        case id, name, price, type, image
    }
}



struct OrderdProducts: Codable, Hashable {
    let id: String
    let productName: String
    let date: String
    let fileName: String
    let updatedAt: String

    enum CodingKeys: String, CodingKey {
        case id
        case productName = "product_name"
        case date
        case fileName = "file_name"
        case updatedAt = "updated_at"
    }
}

struct OrderdProductsDataResponse: Codable {
    let status: String
    let data: [OrderdProducts]
    let message: String
}
