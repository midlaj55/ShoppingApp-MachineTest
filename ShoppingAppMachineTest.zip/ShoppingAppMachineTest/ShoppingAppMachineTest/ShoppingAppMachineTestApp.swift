//
//  ShoppingAppMachineTestApp.swift
//  ShoppingAppMachineTest
//
//  Created by Mc on 22/03/24.
//

import SwiftUI

@main
struct ShoppingAppMachineTestApp: App {
    var body: some Scene {
        WindowGroup {
            BaseView()
        }
    }
}
