//
//  ViewModel.swift
//  ShoppingAppMachineTest
//
//  Created by Mc on 22/03/24.
//

import Foundation
import UIKit

class GroupViewModel: ObservableObject {
    @Published var groupItems: Welcome?
    @Published var product: [Product]?
    @Published var orderdProducts: OrderdProductsDataResponse?
    @Published var productHistory: [OrderdProducts] = []
    
    fileprivate var service = IteamListService()
    init() {
        service.delegate = self
    }
    
    func getItemListValues() {
        service.getAllMoviewCategories()
    }
    

    func saveOrder(productId: String, date: String, image: UIImage) {
        service.uploadMovieDetails(productID: productId, date: date, image: image)
    }

    func getOrderdProductsList() {
        service.getOrderdProducts()
    }

}

extension GroupViewModel: IteamListServiceDelegate {
    func orderdProductSuccessResponse(_ response: OrderdProductsDataResponse) {
        self.orderdProducts = response
        self.productHistory = response.data
    }
    
    func productUnauthorizedResponse() {
        
    }
    
    func productSuccessResponse(_ response: Welcome) {
        self.product = response.data?.product
        self.groupItems = response
    }

    func productFailResponse() {
        
    }
}
