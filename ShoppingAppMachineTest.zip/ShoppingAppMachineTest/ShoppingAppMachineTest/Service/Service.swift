//
//  Service.swift
//  ShoppingAppMachineTest
//
//  Created by Mc on 22/03/24.
//

import Foundation
import Alamofire
import UIKit

protocol IteamListServiceDelegate: AnyObject {
    func productSuccessResponse(_ response: Welcome) // Change the response type
    func orderdProductSuccessResponse(_ response: OrderdProductsDataResponse) // Change the response type
    func productFailResponse()
}

class IteamListService {
    weak var delegate: IteamListServiceDelegate?
    let productData = "http://test.aakri.in/api/test/pre_data"
    let submitProductData = "http://test.aakri.in/api/test/save_order"
    let productHistoryData = "http://test.aakri.in/api/test/history"
    let headers: HTTPHeaders = [
            "Authorization": "Basic YWRtaW46MTIzNA==",
            "session": "WKSSWCCC"
        ]
}

extension IteamListService {
    // MARK: get All Movie Categories list data
    
    func getAllMoviewCategories() {
        let url = URL(string: productData)!
        AF.request(url, method: .get, headers: headers)
            .responseDecodable(of: Welcome.self) { response in // Change the response type
                switch response.result {
                case .success(let value):
                    // Handle successful decoding of JSON response
                    self.delegate?.productSuccessResponse(value) // Pass the entire GroupResponse
                case .failure(let error):
                    // Handle failure
                    self.delegate?.productFailResponse()
                    print("error\(error)")
                }
            }
    }
        
    func uploadMovieDetails(productID: String, date: String, image: UIImage) {
        let url = URL(string: submitProductData)!
        AF.upload(multipartFormData: { multipartFormData in
            multipartFormData.append(Data(productID.utf8), withName: "product_id")
            multipartFormData.append(Data(date.utf8), withName: "date")
            if let imageData = image.jpegData(compressionQuality: 0.8) {
                multipartFormData.append(imageData, withName: "file_name", fileName: "image.jpg", mimeType: "image/jpeg")
            }
        }, to: url, headers: headers)
        .response { response in
            switch response.result {
            case .success(let data):
                print("Success: \(String(describing: data))")
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
    
    func getOrderdProducts() {
        let url = URL(string: productHistoryData)!
        AF.request(url, method: .get, headers: headers)
            .responseDecodable(of: OrderdProductsDataResponse.self) { response in // Change the response type
                switch response.result {
                case .success(let value):
                    // Handle successful decoding of JSON response
                    self.delegate?.orderdProductSuccessResponse(value) // Pass the entire GroupResponse
                case .failure(let error):
                    // Handle failure
                    self.delegate?.productFailResponse()
                    print("error\(error)")
                }
            }
    }}
