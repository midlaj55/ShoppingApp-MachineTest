//
//  TextView.swift
//  ShoppingAppMachineTest
//
//  Created by Mc on 24/03/24.
//

import SwiftUI

struct TextView: View {
    var text: String
    var font: Font
    var color: Color
    var alignment: TextAlignment

    init(text: String, font: Font = .body, color: Color = .black, alignment: TextAlignment = .leading) {
        self.text = text
        self.font = font
        self.color = color
        self.alignment = alignment
    }

    var body: some View {
        HStack {
            Text(text)
                .font(Font.system(size: 20, weight: .bold))
                .foregroundColor(.titleColor)
                .multilineTextAlignment(alignment)
            Spacer()
        }
    }
}

//#Preview {
//    TextView()
//}
