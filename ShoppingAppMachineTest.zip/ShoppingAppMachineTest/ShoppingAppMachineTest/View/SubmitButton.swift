//
//  SubmitButton.swift
//  ShoppingAppMachineTest
//
//  Created by Mc on 24/03/24.
//

import SwiftUI

struct SubmitButton: View {
    @Binding var isSubmitButtonClicked: Bool
    @Binding var selectedImage: UIImage?
    @Binding var selectedProductID: String?
    @Binding var selectedDate: Date
    @ObservedObject var viewModel: GroupViewModel

    var body: some View {
        Button(action: {
            if let image = selectedImage, let productID = selectedProductID {
                viewModel.saveOrder(productId: productID, date: selectedDate.formattedString(), image: image)
                isSubmitButtonClicked = true // Activate the submit button
                viewModel.getOrderdProductsList()
            }
        }) {
            Text("SUBMIT")
                .bold()
                .foregroundColor(.white)
                .padding(.horizontal)
                .frame(width: 120, height: 40)
                .background(Color.cardColor)
                .cornerRadius(10)
                .padding()
        }
    }
}

//#Preview {
//    SubmitButton()
//}
