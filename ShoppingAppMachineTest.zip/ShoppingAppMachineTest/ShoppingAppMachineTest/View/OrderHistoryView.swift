//
//  OrderHistoryView.swift
//  ShoppingAppMachineTest
//
//  Created by Mc on 22/03/24.
//

import SwiftUI
import Kingfisher

struct OrderHistoryView: View {
    @StateObject var viewModel = GroupViewModel()
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack {
            List(viewModel.productHistory, id: \.self) { product in
                OrderHistoryRow(product: product)
            }
            .listStyle(PlainListStyle())
            BackButtonView
        }
        .navigationBarBackButtonHidden(true)
        .onAppear {
            viewModel.getOrderdProductsList()
        }
    }
    
    var BackButtonView: some View {
        Button {
            self.presentationMode.wrappedValue.dismiss() // Dismiss the current view
        } label: {
            Text("BACK")
                .bold()
                .foregroundColor(.white)
                .frame(width: 120, height: 40)
                .background(Color.cardColor)
                .padding()
        }

    }
}

struct OrderHistoryRow: View {
    let product: OrderdProducts
    var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return formatter
    }
    
    var body: some View {
        HStack {
            KFImage(URL(string: product.fileName))
                .resizable()
                .scaledToFit()
                .frame(width: 40, height: 40)
                .contrast(10)
                .padding()
            VStack(alignment: .leading, spacing: 8) {
                Text("Name: \(product.productName)")
                    .font(.headline)
                Text("Date: \(formattedDate(for: product.date))")
                    .font(.headline)
            }
            Spacer()
        }
        .frame(height: 100)
        .foregroundColor(.white)
        .background(Color.cardColor)
        .cornerRadius(10)
    }
}

extension OrderHistoryRow {
    func formattedDate(for dateString: String) -> String {
        guard let date = dateFormatter.date(from: dateString) else {
            return "Invalid Date"
        }
        
        // Customize the date format as per your requirement
        dateFormatter.dateFormat = "MMM dd, yyyy HH:mm"
        return dateFormatter.string(from: date)
    }
}

struct OrderHistoryView_Previews: PreviewProvider {
    static var previews: some View {
        OrderHistoryView()
    }
}
