//
//  SelectImageButton.swift
//  ShoppingAppMachineTest
//
//  Created by Mc on 24/03/24.
//

import SwiftUI

struct SelectImageButton: View {
    @Binding var isShowingImagePicker: Bool

    var body: some View {
        Button(action: {
            isShowingImagePicker.toggle()
        }) {
            Text("Select Image")
                .padding(.horizontal)
                .frame(maxWidth: .infinity, maxHeight: 50)
                .background(Color.lightGrayColor)
                .cornerRadius(10)
        }
    }
}

//#Preview {
//    SelectImageButton()
//}
