//
//  GridItemView.swift
//  ShoppingAppMachineTest
//
//  Created by Mc on 24/03/24.
//

import SwiftUI
import Kingfisher

struct GridItemView: View {
    @StateObject var viewModel = GroupViewModel()
    
    let columns: [GridItem] = Array(repeating: .init(.flexible()), count: 3)
    let spacing: CGFloat = 16
    
    @State private var selectedItem: Product? // Track the selected item
    @Binding var selectedProductID: String? // Binding to store the selected product ID
    
    var body: some View {
        VStack {
            LazyVGrid(columns: columns, spacing: spacing) {
                ForEach(viewModel.product?.prefix(9) ?? [], id: \.id) { product in
                    if let imageURL = product.image,
                       let url = URL(string: imageURL) {
                        VStack {
                            KFImage(url)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(maxWidth: 50, maxHeight: 50)
                            
                            Text(product.name ?? "Name Placeholder")
                                .lineSpacing(0.5)
                                .font(Font.system(size: 10, weight: .regular))
                        }
                        .frame(width: 70, height: 70, alignment: .center)
                        .contrast(10)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(selectedItem == product ? Color.cardColor : Color.clear, lineWidth: 2)
                        )
                        .background(Color.lightGrayColor)
                        .onTapGesture {
                            selectedItem = product
                            selectedProductID = product.id // Assign the selected product ID
                            
                        }
                    } else {
                        Color.clear // Placeholder for empty cells
                    }
                }
            }
            .padding(.horizontal)
        }
        .onAppear {
            viewModel.getItemListValues()
        }
    }
}

//#Preview {
//    GridItemView()
//}
