//
//  File.swift
//  ShoppingAppMachineTest
//
//  Created by Mc on 22/03/24.
//

import Foundation
import SwiftUI

struct CalendarView: View {
    @State private var selectedDate = Date()
    @State private var currentDate = Date()
    @StateObject var viewModel = GroupViewModel()

    var body: some View {
        VStack {
            headerView
            daysGridView
        }
    }

    private var headerView: some View {
        HStack {
            Button(action: {
                self.selectedDate = Calendar.current.date(byAdding: .month, value: -1, to: self.selectedDate)!
            }) {
                Image(systemName: "chevron.left")
            }
            Spacer()
            Text("\(selectedDate, formatter: DateFormatter.monthYearFormatter)")
            Spacer()
            Button(action: {
                self.selectedDate = Calendar.current.date(byAdding: .month, value: 1, to: self.selectedDate)!
            }) {
                Image(systemName: "chevron.right")
            }
        }
        .padding()
    }

    private var daysGridView: some View {
        VStack {
            ForEach(0..<numberOfWeeks(), id: \.self) { weekIndex in
                HStack {
                    ForEach(0..<7, id: \.self) { dayIndex in
                        let day = self.day(for: weekIndex, and: dayIndex)
                        if self.isCurrentMonth(day: day) {
                            Text("\(day)")
                                .frame(width: 30, height: 30)
                                .padding(5)
                                .background(self.isDateSelected(day: day) ? Color.red : Color.clear)
                                .clipShape(Circle())
                                .onTapGesture {
                                    self.selectedDate = self.date(for: weekIndex, and: dayIndex)
                                }
                        } else if self.isNextMonth(day: day) {
                            Text("\(day)")
                                .frame(width: 30, height: 30)
                                .padding(5)
                                .background(self.isNextMonthDateSelected(day: day) ? Color.red : Color.clear)
                                .clipShape(Circle())
                                .onTapGesture {
                                    self.selectedDate = self.date(for: weekIndex, and: dayIndex)
                                }
                        } else {
                            Text("") // Placeholder for non-current month days
                                .frame(width: 30, height: 30)
                        }
                    }
                }
            }
        }
    }

    private func numberOfWeeks() -> Int {
        let range = Calendar.current.range(of: .weekOfMonth, in: .month, for: selectedDate)!
        return range.count
    }

    private func day(for weekIndex: Int, and dayIndex: Int) -> Int {
        let dayOffset = (dayIndex - firstDayIndex()) + (weekIndex * 7)
        return Calendar.current.component(.day, from: Calendar.current.date(byAdding: .day, value: dayOffset, to: firstDayOfMonth())!)
    }

    private func date(for weekIndex: Int, and dayIndex: Int) -> Date {
        let dayOffset = (dayIndex - firstDayIndex()) + (weekIndex * 7)
        return Calendar.current.date(byAdding: .day, value: dayOffset, to: firstDayOfMonth())!
    }

    private func firstDayOfMonth() -> Date {
        return Calendar.current.date(from: Calendar.current.dateComponents([.year, .month], from: selectedDate))!
    }

    private func firstDayIndex() -> Int {
        let weekday = Calendar.current.component(.weekday, from: firstDayOfMonth())
        return weekday - 1 // Adjusting to 0-based index
    }

    private func isCurrentMonth(day: Int) -> Bool {
        let components = Calendar.current.dateComponents([.year, .month], from: selectedDate)
        if let currentMonth = components.month {
            return currentMonth == Calendar.current.component(.month, from: firstDayOfMonth())
        }
        return false
    }

    private func isNextMonth(day: Int) -> Bool {
        let components = Calendar.current.dateComponents([.year, .month], from: selectedDate)
        if let nextMonth = Calendar.current.date(byAdding: .month, value: 1, to: firstDayOfMonth()) {
            return day == Calendar.current.component(.day, from: nextMonth)
        }
        return false
    }

    private func isDateSelected(day: Int) -> Bool {
        guard let currentMonthScrapAvailabilityData = viewModel.groupItems?.data?.availableDates?.currentMonthScrapAvailability?.data(using: .utf8) else {
            return false
        }
        do {
            let currentMonthScrapAvailability = try JSONDecoder().decode([String: Int].self, from: currentMonthScrapAvailabilityData)
            let key = "day\(day)"
            return currentMonthScrapAvailability[key] != nil
        } catch {
            print("Error decoding current month availability data: \(error)")
            return false
        }
    }

    private func isNextMonthDateSelected(day: Int) -> Bool {
        guard let nextMonthScrapAvailabilityData = viewModel.groupItems?.data?.availableDates?.nextMonthScrapAvailability?.data(using: .utf8) else {
            return false
        }
        do {
            let nextMonthScrapAvailability = try JSONDecoder().decode([String: Int].self, from: nextMonthScrapAvailabilityData)
            let key = "day\(day)"
            return nextMonthScrapAvailability[key] != nil
        } catch {
            print("Error decoding next month availability data: \(error)")
            return false
        }
    }
}

extension DateFormatter {
    static let monthYearFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM yyyy"
        return formatter
    }()
}

struct CalendarView_Previews: PreviewProvider {
    static var previews: some View {
        CalendarView()
    }
}
