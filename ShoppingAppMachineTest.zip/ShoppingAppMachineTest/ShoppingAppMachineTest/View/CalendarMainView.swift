//
//  CalendarMainView.swift
//  ShoppingAppMachineTest
//
//  Created by Mc on 24/03/24.
//

import SwiftUI

struct CalendarMainView: View {
    @Binding var selectedDate: Date
    var availableDates: AvailableDates?

    var body: some View {
        CalendarSFView(availableDates: availableDates, selectedDate: $selectedDate)
            .frame(width: 200, height: 200)
            .padding()
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.black, lineWidth: 1)
            )
    }
}

//#Preview {
//    CalendarMainView()
//}
