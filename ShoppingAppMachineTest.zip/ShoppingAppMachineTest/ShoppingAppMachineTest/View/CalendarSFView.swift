//
//  CalendarView.swift
//  ShoppingAppMachineTest
//
//  Created by Mc on 22/03/24.
//

import SwiftUI
import FSCalendar

struct CalendarSFView: UIViewRepresentable {
    typealias UIViewType = FSCalendar

    let calendar = FSCalendar()
    let availableDates: AvailableDates?
    @Binding var selectedDate: Date // Binding to receive the selected date
    
    init(availableDates: AvailableDates?, selectedDate: Binding<Date>) {
        self.availableDates = availableDates
        self._selectedDate = selectedDate
    }

    func makeUIView(context: Context) -> FSCalendar {
        calendar.delegate = context.coordinator
        calendar.appearance.headerTitleColor = .white
        calendar.appearance.headerTitleFont = UIFont.boldSystemFont(ofSize: 20)
        calendar.appearance.headerDateFormat = "MMMM yyyy"
        calendar.calendarHeaderView.backgroundColor = Color.calendarColor
        return calendar
    }

    func updateUIView(_ uiView: FSCalendar, context: Context) {}

    func makeCoordinator() -> Coordinator {
        return Coordinator(self)
    }

    class Coordinator: NSObject, FSCalendarDelegate {
        var parent: CalendarSFView

        init(_ parent: CalendarSFView) {
            self.parent = parent
        }

        func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
            parent.selectedDate = date
        }

        func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, fillDefaultColorFor date: Date) -> UIColor? {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"

            if let currentMonthAvailability = parent.availableDates?.currentMonthScrapAvailability,
               let currentMonthDates = currentMonthAvailability.dictionaryFromString() {
                let dateString = dateFormatter.string(from: date)
                if let _ = currentMonthDates[dateString] {
                    return .red
                }
            }
            return nil
        }
    }
}

extension Date {
    func formattedString() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        return dateFormatter.string(from: self)
    }
}

extension String {
    func dictionaryFromString() -> [String: Int]? {
        guard let data = self.data(using: .utf8) else { return nil }
        do {
            return try JSONDecoder().decode([String: Int].self, from: data)
        } catch {
            print("Error decoding JSON string: \(error)")
            return nil
        }
    }
}
