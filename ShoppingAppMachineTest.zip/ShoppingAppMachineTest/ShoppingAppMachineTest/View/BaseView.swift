//
//  BaseView.swift
//  ShoppingAppMachineTest
//
//  Created by Mc on 22/03/24.
//

import SwiftUI
import FSCalendar
import Kingfisher

struct BaseView: View {
    @StateObject var viewModel = GroupViewModel()
    @State private var selectedImage: UIImage? = nil
    @State private var isShowingImagePicker = false
    @State private var selectedProductID: String? // Store the selected product ID
    @State private var selectedDate: Date = Date() // Store the selected date
    @State private var apiSuccess = false
    @State private var isSubmitButtonClicked = false // Track if submit button is clicked
    
    var body: some View {
        NavigationView {
            VStack {
                TextView(text: "Products")
                GridItemView(selectedProductID: $selectedProductID)
                TextView(text: "Select Date")
                CalendarMainView(selectedDate: $selectedDate, availableDates: viewModel.groupItems?.data?.availableDates)
                TextView(text: "Add image")
                SelectImageButton(isShowingImagePicker: $isShowingImagePicker)
                SubmitButton(isSubmitButtonClicked: $isSubmitButtonClicked, selectedImage: $selectedImage,
                             selectedProductID: $selectedProductID, selectedDate: $selectedDate, viewModel: viewModel)
                if apiSuccess || isSubmitButtonClicked { // Activate navigation when apiSuccess or isSubmitButtonClicked is true
                    NavigationLink(destination: OrderHistoryView(),
                                   isActive: $isSubmitButtonClicked) {
                        EmptyView()
                    }
                }
            }
            .padding()
            .onAppear {
                viewModel.getItemListValues()
            }
            .sheet(isPresented: $isShowingImagePicker) {
                ImageSelectionButton(selectedImage: $selectedImage)
            }
        }
    }
}

struct BaseView_Previews: PreviewProvider {
    static var previews: some View {
        BaseView()
    }
}
