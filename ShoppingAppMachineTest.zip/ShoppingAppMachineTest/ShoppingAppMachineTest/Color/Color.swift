//
//  File.swift
//  ShoppingAppMachineTest
//
//  Created by Mc on 24/03/24.
//

import SwiftUI

extension Color {
    static let cardColor = Color("color0E5D33")
    static let calendarColors = Color("color6B8E23")
    static let titleColor = Color("color00BC58")
    static let lightGrayColor = Color("colorDEDAD9")
    
    static let calendarColor = UIColor(named: "color6B8E23")
}
